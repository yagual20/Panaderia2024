package com.example.mykotlinlist

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.webkit.WebViewClientCompat

class VerInformacion : AppCompatActivity() {
    private lateinit var webWiew: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ver_informacion)

        webWiew = findViewById(R.id.webViewInformacion)
        val url = intent.getStringExtra("informacion_en_film_affinity") as String
        webWiew.loadUrl(url)

        webWiew.webViewClient = object : WebViewClientCompat() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String): Boolean {
                view?.loadUrl(url)
                return true
            }
        }



    }
}