package com.example.mykotlinlist.productos

class Productos (
    val nombreDeProducto:String,
    val categoriaDeProducto:String,
    val supermercado:String,
    val precio:String,

)