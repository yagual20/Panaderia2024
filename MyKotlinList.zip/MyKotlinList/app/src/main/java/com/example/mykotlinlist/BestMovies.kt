package com.example.mykotlinlist

data class BestMovies(
    val nombreDeProducto:String,
    val categoriaDeProducto:String,
    val supermercado:String,
    val precio:String,
    //val director:String,
    //val supermercadoNo:String,
    val image:String,
    val trailer:String,
    val informacion_en_film_affinity:String
) {

}