package com.example.mykotlinlist

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ActivityInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView

class DescriptionActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)

        val moviesTitle = intent.getStringExtra("trailer")
        val informacion = intent.getStringExtra("informacion_en_film_affinity")

        //boton ver informacion
        val btnVerInformacion = findViewById<Button>(R.id.btn_ver_informacion)
        btnVerInformacion.setOnClickListener {
            val intent = Intent(this, VerInformacion::class.java)
            intent.putExtra("informacion_en_film_affinity", informacion)
            startActivity(intent)
        }


        //boton ver pelicula
        val btnVerPelicula = findViewById<Button>(R.id.btn_ver_pelicula)
        btnVerPelicula.setOnClickListener {
            val intent = Intent(this, VerPelicula::class.java)
            intent.putExtra("trailer", moviesTitle)
            startActivity(intent)
        }
    }
}